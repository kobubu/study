## **Вебинар 8: Интеграция HDFS + MapReduce и итоги курса**


---

## **1. Data Lake на HDFS: от теории к практике**

# Эволюция хранения данных в Big Data

## Исторический контекст развития систем хранения

```mermaid
timeline
    title Эволюция архитектуры хранения данных
    section 2000-е годы
        Традиционные БД
        : Реляционные СУБД<br>Структурированные данные
    section 2010-е годы  
        Data Warehouse
        : ETL-процессы<br>Оптимизация для отчетности
    section 2020-е годы
        Data Lake
        : Все типы данных<br>Схема-on-read
```

## Детальный разбор архитектурных подходов

### 1. Традиционные базы данных (2000-е годы)

| Аспект | Характеристика | Ограничения |
|--------|----------------|-------------|
| **Тип данных** | Только структурированные | JSON, XML сложно обрабатывать |
| **Схема** | Schema-on-write | Жесткие требования к структуре |
| **Объем** | ГБ-ТБ данных | Дорогое вертикальное масштабирование |
| **Процессинг** | ACID транзакции | Плохая параллельная обработка |

**Ключевые технологии:** Oracle, MySQL, PostgreSQL

---

### 2. Data Warehouse (2010-е годы)

```python
# Архитектура Data Warehouse
DWH_ARCHITECTURE = {
    "data_sources": ["ERP", "CRM", "Логи веб-сайта"],
    "etl_process": "Extract → Transform → Load", 
    "storage": "Column-oriented (Vertica, Redshift)",
    "consumption": ["BI-отчеты", "Дашборды", "OLAP-кубы"]
}
```

**Преимущества:**
- Оптимизация для аналитических запросов
- Высокая скорость выполнения отчетов  
- Поддержка сложных агрегаций

**Ограничения:**
- Дорогое масштабирование
- Сложность ETL-процессов
- Только для структурированных данных

---

### 3. Data Lake (2020-е годы) — Фокус нашего курса

## Сравнительная таблица подходов

| Параметр | Традиционные БД | Data Warehouse | Data Lake |
|----------|-----------------|----------------|-----------|
| **Типы данных** | Структурированные | Структурированные | Все типы |
| **Стоимость хранения** | Высокая | Очень высокая | Низкая |
| **Гибкость схемы** | Schema-on-write | Schema-on-write | Schema-on-read |
| **Время доступа** | Миллисекунды | Секунды-минуты | Минуты-часы |
| **Масштабирование** | Вертикальное | Вертикальное | Горизонтальное |



### Технические преимущества

```python
DATA_LAKE_ADVANTAGES = {
    "storage_cost": "Дешевое горизонтальное масштабирование",
    "data_variety": "Поддержка всех форматов (JSON, CSV, Parquet, Avro)",
    "processing": "Пакетная обработка через MapReduce/Spark", 
    "schema_flexibility": "Читаем схему при анализе, а не при записи",
    "ecosystem": "Интеграция со всей экосистемой Hadoop"
}
```

## Data Lake в действии: Наш ритейл-кейс

### Структура Data Lake для ритейл-аналитики

```bash
/data/
├── raw/                          # Bronze Layer
│   ├── transactions/
│   │   ├── 2024/01/             # JSON, CSV файлы
│   │   ├── 2024/02/
│   │   └── incremental/
│   ├── customers/               # Данные из CRM
│   └── products/                # Справочники товаров
├── staged/                      # Silver Layer  
│   ├── cleaned_transactions/    # Очищенные данные
│   ├── enriched_customers/      # Обогащенные профили
│   └── product_catalog/         # Нормализованный каталог
└── analytics/                   # Gold Layer
    ├── daily_sales/             # Готовые агрегаты
    ├── customer_segments/       # ML-сегменты
    └── business_metrics/        # KPI для руководства
```

### Процесс работы с данными

```mermaid
graph LR
    A[Источники данных] --> B[Raw Layer]
    B --> C[MapReduce ETL]
    C --> D[Staged Layer] 
    D --> E[Аналитика]
    E --> F[Gold Layer]
    F --> G[Бизнес-отчеты]
```

---


# Архитектура Data Lake на HDFS: от теории к практике

## Принципы организации Data Lake

### Многослойная архитектура (Medallion Architecture)

```python
DATA_LAKE_LAYERS = {
    "bronze_layer": {
        "purpose": "Сырые данные как есть",
        "format": "Исходные форматы (JSON, CSV, logs)",
        "retention": "Длительное хранение",
        "access": "Только для ETL процессов"
    },
    "silver_layer": {
        "purpose": "Очищенные и обогащенные данные", 
        "format": "Оптимизированные форматы (Parquet, Avro)",
        "retention": "Среднесрочное хранение",
        "access": "Для аналитиков и Data Scientists"
    },
    "gold_layer": {
        "purpose": "Готовые бизнес-метрики и агрегаты",
        "format": "Высокопроизводительные форматы (Parquet, ORC)",
        "retention": "Длительное хранение агрегатов",
        "access": "Для бизнес-пользователей и отчетности"
    }
}
```

### Принципы именования и организации

```bash
# Стандартная структура папок в HDFS
/data/
└── {домен}/
    └── {тип_данных}/
        └── {версия}/
            └── {партиции}/
```

**Пример для ритейла:**
```bash
/data/retail/transactions/v1/year=2024/month=01/day=15/
/data/retail/transactions/v1/year=2024/month=01/day=16/
```

## Ключевые концепции Data Governance

### Метаданные и каталогизация

```python
class DataAsset:
    def __init__(self, path, schema, owner, quality_metrics):
        self.path = path              # HDFS путь
        self.schema = schema          # Структура данных
        self.owner = owner            # Владелец данных
        self.quality_metrics = {      # Метрики качества
            'completeness': 0.95,     # Полнота данных
            'accuracy': 0.98,         # Точность
            'freshness': '1h'         # Актуальность
        }
        self.lineage = []             # Происхождение данных
```

### Управление доступом и безопасность

```bash
# Пример настройки прав в HDFS
hdfs dfs -chmod -R 750 /data/retail/transactions
hdfs dfs -chown -R analytics_team:analytics /data/retail/transactions
hdfs dfs -setfacl -m user:bi_team:r-x /data/retail/analytics
```

## Оптимизация хранения в HDFS

### Форматы данных для разных сценариев

| Формат | Use Case | Преимущества | Недостатки |
|--------|----------|--------------|------------|
| **Parquet** | Аналитические запросы | Колоночное хранение, сжатие | Медленная запись |
| **ORC** | Hive-запросы | Высокое сжатие, индексы | Меньше инструментов |
| **Avro** | Сериализация | Эволюция схемы, быстрая запись | Большой размер |
| **SequenceFile** | Промежуточные данные | Разделимость, сжатие | Устаревший формат |

### Стратегии партиционирования

```python
PARTITIONING_STRATEGIES = {
    "temporal": {
        "example": "/data/events/year=2024/month=01/day=15/",
        "use_case": "Временные ряды, логи",
        "benefits": "Предикат pushdown, управление TTL"
    },
    "categorical": {
        "example": "/data/products/category=electronics/brand=samsung/", 
        "use_case": "Товары, пользователи",
        "benefits": "Локализация данных, фильтрация"
    },
    "hybrid": {
        "example": "/data/sales/region=north/year=2024/month=01/",
        "use_case": "Комплексные сценарии", 
        "benefits": "Максимальная оптимизация запросов"
    }
}
```

## Мониторинг и управление жизненным циклом

### Метрики для мониторинга Data Lake

```bash
# Мониторинг использования пространства
hdfs dfs -du -h /data/
hdfs dfs -count -q /data/retail

# Проверка здоровья данных
hdfs fsck /data/retail -files -blocks -locations

# Аудит доступа
hdfs dfs -ls -R /data/retail/transactions
```

### Политики жизненного цикла

```python
RETENTION_POLICIES = {
    "raw_data": {
        "hot_storage": "30 дней",      # Быстрый доступ
        "warm_storage": "1 год",       # Архивное хранение  
        "cold_storage": "7 лет",       # Долгосрочный архив
        "deletion": "после 10 лет"     # Окончательное удаление
    },
    "processed_data": {
        "hot_storage": "90 дней",
        "warm_storage": "2 года", 
        "cold_storage": "5 лет",
        "deletion": "после 7 лет"
    }
}
```

## Интеграция с экосистемой Hadoop

### Взаимодействие компонентов

```mermaid
graph TB
    A[Источники данных] --> B[HDFS Raw Layer]
    B --> C[MapReduce ETL]
    C --> D[HDFS Staged Layer]
    D --> E[Hive/Spark Analytics]
    E --> F[HDFS Gold Layer]
    F --> G[BI Tools]
    F --> H[ML Platforms]
    
    style B fill:#e1f5fe
    style D fill:#f3e5f5  
    style F fill:#e8f5e8
```

### Роль MapReduce в Data Lake

```python
MAPREDUCE_DATA_LAKE_ROLES = {
    "data_ingestion": "Загрузка и преобразование сырых данных",
    "data_cleaning": "Очистка и валидация данных", 
    "data_enrichment": "Обогащение данных дополнительными атрибутами",
    "aggregation": "Создание бизнес-агрегатов и метрик",
    "data_migration": "Миграция между слоями Data Lake"
}
```

## Практические паттерны для ритейл-аналитики

### Организация данных для ритейла

```bash
# Структура для ритейл-аналитики
/data/retail/
├── raw/
│   ├── transactions/           # Транзакционные данные
│   │   ├── pos/               # Данные с касс
│   │   ├── online/            # Онлайн-заказы
│   │   └── mobile/            # Мобильные покупки
│   ├── customers/             # Данные клиентов
│   │   ├── profiles/          # Профили
│   │   ├── behavior/          # Поведенческие данные
│   │   └── loyalty/           # Программа лояльности
│   └── products/              # Справочники товаров
│       ├── catalog/           # Каталог товаров
│       ├── inventory/         # Остатки на складах
│       └── pricing/           # Цены и акции
├── staged/
│   ├── unified_transactions/  # Объединенные транзакции
│   ├── customer_360/          # 360° вид клиента
│   └── product_master/        # Единый справочник товаров
└── analytics/
    ├── business_kpis/         # Ключевые метрики
    ├── customer_segments/     # Сегменты клиентов
    ├── product_performance/   # Эффективность товаров
    └── time_series/           # Временные ряды продаж
```

### Паттерны обработки данных

```python
class RetailDataPatterns:
    
    def customer_lifetime_value(self):
        """Расчет пожизненной ценности клиента"""
        return {
            "input": ["transactions", "customer_profiles"],
            "processing": "MapReduce агрегация по клиентам",
            "output": "CLV метрики для сегментации"
        }
    
    def product_affinity_analysis(self):
        """Анализ сопутствующих товаров"""
        return {
            "input": "transaction_baskets", 
            "processing": "MapReduce frequent itemset mining",
            "output": "Рекомендации для кросс-продаж"
        }
    
    def seasonal_trends(self):
        """Выявление сезонных трендов"""
        return {
            "input": "historical_transactions",
            "processing": "MapReduce временные агрегаты", 
            "output": "Прогнозы спроса по сезонам"
        }
```

## Наиболее эффективные практики для продакшн окружения

### Рекомендации по настройке HDFS

```bash
# Конфигурация для Data Lake
# hdfs-site.xml
<property>
    <name>dfs.replication</name>
    <value>3</value>  # Репликация для надежности
</property>
<property>
    <name>dfs.blocksize</name> 
    <value>268435456</value>  # 256MB блоки для больших файлов
</property>
```

### Мониторинг и алертинг

```python
MONITORING_METRICS = {
    "storage_metrics": [
        "hdfs_capacity_used",
        "hdfs_capacity_remaining", 
        "data_growth_rate"
    ],
    "performance_metrics": [
        "mapreduce_job_duration",
        "hdfs_io_throughput",
        "namenode_rpc_latency"
    ],
    "quality_metrics": [
        "data_freshness",
        "schema_compliance", 
        "completeness_checks"
    ]
}
```

---

# Практическая часть: End-to-End пайплайн анализа ритейл-данных

## Архитектура решения

```mermaid
graph TB
    A[Локальные данные<br/>/data/input/retail_sales_dataset.csv] --> B[HDFS Data Lake]
    B --> C[MapReduce Processing<br/>Hadoop Cluster]
    
    subgraph "Hadoop Cluster"
        C --> D1[Namenode<br/>Управление]
        C --> D2[Datanode 1<br/>Хранение]
        C --> D3[Datanode 2<br/>Хранение]
        C --> D4[Datanode 3<br/>Хранение]
    end
    
    D1 --> E[MapReduce Jobs<br/>7 аналитических модулей]
    
    subgraph "Analytics Modules"
        E --> F1[Secondary Sort<br/>Динамика продаж]
        E --> F2[Composite Keys<br/>Демография]
        E --> F3[Multiple Outputs<br/>Мультиметрика]
        E --> F4[Price Elasticity<br/>Эластичность]
        E --> F5[Demographic Analysis<br/>Сегментация]
        E --> F6[Time Patterns<br/>Временные паттерны]
        E --> F7[Revenue Dynamics<br/>Выручка]
    end
    
    F1 --> G[HDFS Results Storage<br/>/data/retail/analytics/]
    F2 --> G
    F3 --> G
    F4 --> G
    F5 --> G
    F6 --> G
    F7 --> G
    
    G --> H[Visualization Pipeline<br/>Python/Matplotlib]
    H --> I[Analytics Dashboard<br/>PNG файлы]
    
    I --> J[Business Insights<br/>Отчеты и инсайты]
```

## Часть 1: Подготовка и настройка кластера

### 1.1. Подготовка структуры проекта

```bash
# Внутри хоста (не в контейнере)
cd ~/hadoop_retail_analysis

# Проверяем структуру
tree -L 3

# Видим:
# ├── advanced_analytics/
# │   ├── composite_keys.py
# │   ├── demographic_category_analysis.py
# │   ├── multiple_outputs.py
# │   ├── real_price_elasticity.py
# │   ├── revenue_dynamics.py
# │   ├── secondary_sort.py
# │   └── time_pattern_analysis.py
# └── scripts/
#     └── (дублирующие файлы)
```

### 1.2. Создание мастер-скрипта пайплайна

**`advanced_analytics/run_retail_pipeline.py`**

<details>

<summarize>Скрипт</summarize>

```python
#!/usr/bin/env python3
"""
Мастер-скрипт пайплайна для ритейл-аналитики
Координирует выполнение всех 7 MapReduce заданий
"""

import subprocess
import time
import os
from datetime import datetime

class RetailAnalyticsMaster:
    def __init__(self):
        self.script_dir = "/scripts/advanced_analytics"
        self.hdfs_base = "/data/retail"
        self.input_file = f"{self.hdfs_base}/retail_sales_dataset.csv"
        
        # Определяем все аналитические модули
        self.modules = [
            {
                "name": "Вторичная сортировка - Анализ продаж",
                "script": "secondary_sort.py",
                "output": f"{self.hdfs_base}/analytics/sales_trends",
                "description": "Анализ динамики продаж по месяцам и категориям"
            },
            {
                "name": "Составные ключи - Сегментация", 
                "script": "composite_keys.py",
                "output": f"{self.hdfs_base}/analytics/customer_segments",
                "description": "Многомерная сегментация клиентов по демографии и поведению"
            },
            {
                "name": "Multiple Outputs - Мультиметрика",
                "script": "multiple_outputs.py", 
                "output": f"{self.hdfs_base}/analytics/product_performance",
                "description": "Комплексная аналитика продукта из одного задания"
            },
            {
                "name": "Ценовая эластичность - Анализ спроса",
                "script": "real_price_elasticity.py",
                "output": f"{self.hdfs_base}/analytics/price_analysis",
                "description": "Анализ зависимости спроса от цены по категориям"
            },
            {
                "name": "Демографический анализ - Сегменты",
                "script": "demographic_category_analysis.py",
                "output": f"{self.hdfs_base}/analytics/demographic_analysis",
                "description": "Анализ покупательского поведения по возрасту, полу и категориям"
            },
            {
                "name": "Временные паттерны - Сезонность", 
                "script": "time_pattern_analysis.py",
                "output": f"{self.hdfs_base}/analytics/time_patterns",
                "description": "Выявление сезонных и недельных паттернов покупок"
            },
            {
                "name": "Динамика выручки - Бизнес-метрики",
                "script": "revenue_dynamics.py",
                "output": f"{self.hdfs_base}/analytics/revenue_dynamics",
                "description": "Анализ среднего чека и ключевых метрик эффективности"
            }
        ]
    
    def setup_hdfs_infrastructure(self):
        """Создание структуры директорий HDFS"""
        print("=" * 70)
        print("НАСТРОЙКА ИНФРАСТРУКТУРЫ HDFS")
        print("=" * 70)
        
        # Создаем основные директории
        directories = [
            self.hdfs_base,
            f"{self.hdfs_base}/analytics",
            f"{self.hdfs_base}/analytics/sales_trends",
            f"{self.hdfs_base}/analytics/customer_segments", 
            f"{self.hdfs_base}/analytics/product_performance",
            f"{self.hdfs_base}/analytics/price_analysis",
            f"{self.hdfs_base}/analytics/demographic_analysis",
            f"{self.hdfs_base}/analytics/time_patterns",
            f"{self.hdfs_base}/analytics/revenue_dynamics"
        ]
        
        for directory in directories:
            cmd = f"hdfs dfs -mkdir -p {directory}"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✓ Создано: {directory}")
            else:
                print(f"✗ Ошибка создания {directory}: {result.stderr}")
        
        # Проверяем наличие данных в HDFS
        check_cmd = f"hdfs dfs -test -e {self.input_file}"
        result = subprocess.run(check_cmd, shell=True, capture_output=True)
        
        if result.returncode != 0:
            print("\nЗагрузка данных в HDFS...")
            local_data = "/data/input/retail_sales_dataset.csv"
            upload_cmd = f"hdfs dfs -put {local_data} {self.input_file}"
            subprocess.run(upload_cmd, shell=True)
            print(f"✓ Данные загружены в: {self.input_file}")
        else:
            print(f"✓ Данные уже находятся в HDFS: {self.input_file}")
        
        print("\nСтруктура HDFS:")
        subprocess.run(f"hdfs dfs -ls -R {self.hdfs_base}", shell=True)
    
    def execute_mapreduce_job(self, module):
        """Выполнение одного MapReduce задания"""
        print(f"\n{'='*70}")
        print(f"ВЫПОЛНЕНИЕ: {module['name']}")
        print(f"Описание: {module['description']}")
        print(f"{'='*70}")
        
        # Формируем команду
        script_path = f"{self.script_dir}/{module['script']}"
        cmd = f"python3 {script_path} -r hadoop hdfs://{self.input_file} --output-dir hdfs://{module['output']}"
        
        print(f"Команда: {cmd}")
        
        # Очищаем предыдущие результаты
        subprocess.run(f"hdfs dfs -rm -r {module['output']} 2>/dev/null", shell=True)
        
        # Выполняем задание с замером времени
        start_time = time.time()
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        execution_time = time.time() - start_time
        
        # Проверяем результаты
        if result.returncode == 0:
            print(f"\n✓ УСПЕХ: {module['name']}")
            print(f"Время выполнения: {execution_time:.2f} секунд")
            print(f"Результаты: {module['output']}")
            
            # Проверяем выходные файлы
            verify_cmd = f"hdfs dfs -ls {module['output']}/part* 2>/dev/null | head -3"
            subprocess.run(verify_cmd, shell=True)
            
            # Показываем пример вывода
            print("\nПример результатов (первые 2 строки):")
            sample_cmd = f"hdfs dfs -cat {module['output']}/part-00000 2>/dev/null | head -2"
            subprocess.run(sample_cmd, shell=True)
            
            return True
        else:
            print(f"\n✗ ОШИБКА: {module['name']}")
            print(f"Сообщение об ошибке: {result.stderr[:500]}")
            return False
    
    def run_visualization_pipeline(self):
        """Запуск скриптов визуализации для всей аналитики"""
        print(f"\n{'='*70}")
        print("ПАЙПЛАЙН ВИЗУАЛИЗАЦИИ ДАННЫХ")
        print(f"{'='*70}")
        
        # Список скриптов визуализации
        viz_scripts = [
            "visualize_secondary_sort.py",
            "visualize_composite_keys.py", 
            "visualize_multiple_outputs.py",
            "visualize_real_price_elasticity.py",
            "visualize_demographic_category.py",
            "visualize_time_patterns.py",
            "visualize_revenue_dynamics.py"
        ]
        
        visualization_results = []
        
        for viz_script in viz_scripts:
            script_path = f"/scripts/{viz_script}"
            
            if os.path.exists(script_path):
                print(f"\nЗапуск: {viz_script}")
                
                # Загружаем данные из HDFS для визуализации
                self.prepare_data_for_visualization(viz_script)
                
                # Выполняем визуализацию
                start_time = time.time()
                result = subprocess.run(f"python3 {script_path}", shell=True, capture_output=True)
                viz_time = time.time() - start_time
                
                if result.returncode == 0:
                    output_file = viz_script.replace('visualize_', '').replace('.py', '_analysis.png')
                    print(f"✓ Создано: {output_file} ({viz_time:.1f}с)")
                    visualization_results.append(output_file)
                else:
                    print(f"✗ Ошибка: {viz_script}")
        
        return visualization_results
    
    def prepare_data_for_visualization(self, viz_script):
        """Подготовка данных HDFS для скриптов визуализации"""
        # Сопоставляем скрипты визуализации с путями HDFS
        hdfs_mapping = {
            'visualize_secondary_sort.py': f"{self.hdfs_base}/analytics/sales_trends",
            'visualize_composite_keys.py': f"{self.hdfs_base}/analytics/customer_segments",
            'visualize_multiple_outputs.py': f"{self.hdfs_base}/analytics/product_performance",
            'visualize_real_price_elasticity.py': f"{self.hdfs_base}/analytics/price_analysis",
            'visualize_demographic_category.py': f"{self.hdfs_base}/analytics/demographic_analysis",
            'visualize_time_patterns.py': f"{self.hdfs_base}/analytics/time_patterns",
            'visualize_revenue_dynamics.py': f"{self.hdfs_base}/analytics/revenue_dynamics"
        }
        
        if viz_script in hdfs_mapping:
            hdfs_path = hdfs_mapping[viz_script]
            local_path = f"/tmp/{viz_script.replace('.py', '')}"
            
            # Очищаем и создаем локальную директорию
            subprocess.run(f"rm -rf {local_path}", shell=True)
            subprocess.run(f"mkdir -p {local_path}", shell=True)
            
            # Загружаем данные из HDFS
            download_cmd = f"hdfs dfs -get {hdfs_path}/part* {local_path}/ 2>/dev/null"
            subprocess.run(download_cmd, shell=True)
            
            print(f"  Данные загружены из: {hdfs_path}")
    
    def generate_comprehensive_report(self, results, visualizations):
        """Генерация итогового отчета пайплайна"""
        report = f"""
ПАЙПЛАЙН РИТЕЙЛ-АНАЛИТИКИ - ИТОГОВЫЙ ОТЧЕТ
{'='*70}

Общая информация:
- Дата выполнения: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- Всего модулей: {len(self.modules)}
- Успешно выполнено: {sum(1 for r in results.values() if r)}
- Ошибок: {sum(1 for r in results.values() if not r)}

Подробные результаты:
"""
        
        for module_name, success in results.items():
            status = "✓ УСПЕШНО" if success else "✗ ОШИБКА"
            report += f"- {module_name}: {status}\n"
        
        report += f"""
Результаты визуализации:
"""
        
        for viz in visualizations:
            report += f"- {viz}\n"
        
        report += f"""
Структура результатов в HDFS:
"""
        
        # Получаем структуру HDFS
        hdfs_cmd = f"hdfs dfs -ls -R {self.hdfs_base}/analytics"
        hdfs_result = subprocess.run(hdfs_cmd, shell=True, capture_output=True, text=True)
        report += hdfs_result.stdout
        
        report += f"""
Выполненные команды пайплайна:
"""
        
        for module in self.modules:
            report += f"- python3 {module['script']} -r hadoop hdfs://{self.input_file} --output-dir hdfs://{module['output']}\n"
        
        # Сохраняем отчет
        report_path = "/scripts/pipeline_execution_report.txt"
        with open(report_path, 'w') as f:
            f.write(report)
        
        print(f"\n✓ Итоговый отчет сохранен: {report_path}")
        
        # Выводим краткую сводку
        print(f"\n{'='*70}")
        print("ВЫПОЛНЕНИЕ ПАЙПЛАЙНА ЗАВЕРШЕНО")
        print(f"{'='*70}")
        print(f"Аналитические модули: {sum(1 for r in results.values() if r)}/{len(self.modules)} успешно")
        print(f"Визуализации создано: {len(visualizations)}")
        print(f"Результаты находятся в: {self.hdfs_base}/analytics/")
        print(f"Отчет: {report_path}")
        print(f"{'='*70}")
    
    def execute_full_pipeline(self):
        """Выполнение полного аналитического пайплайна"""
        print(f"{'='*70}")
        print("END-TO-END ПАЙПЛАЙН РИТЕЙЛ-АНАЛИТИКИ")
        print(f"{'='*70}")
        print("Конфигурация:")
        print(f"- Директория скриптов: {self.script_dir}")
        print(f"- База HDFS: {self.hdfs_base}")
        print(f"- Входные данные: {self.input_file}")
        print(f"- Модули: {len(self.modules)} аналитических заданий")
        print(f"{'='*70}\n")
        
        # Шаг 1: Настройка HDFS
        self.setup_hdfs_infrastructure()
        
        # Шаг 2: Выполнение всех MapReduce заданий
        print(f"\n{'='*70}")
        print("ВЫПОЛНЕНИЕ MAPREDUCE АНАЛИТИЧЕСКИХ ЗАДАНИЙ")
        print(f"{'='*70}")
        
        results = {}
        
        for i, module in enumerate(self.modules, 1):
            print(f"\n[{i}/{len(self.modules)}] ", end="")
            success = self.execute_mapreduce_job(module)
            results[module['name']] = success
            
            # Небольшая задержка между заданиями
            if i < len(self.modules):
                print("\n" + "-"*50)
                print("Подготовка следующего задания...")
                time.sleep(3)
        
        # Шаг 3: Визуализация
        visualizations = self.run_visualization_pipeline()
        
        # Шаг 4: Генерация отчета
        self.generate_comprehensive_report(results, visualizations)
        
        # Финальный статус
        all_success = all(results.values())
        return all_success

if __name__ == "__main__":
    print("\n" + "="*70)
    print("ИНИЦИАЛИЗАЦИЯ ПАЙПЛАЙНА РИТЕЙЛ-АНАЛИТИКИ")
    print("="*70)
    
    # Проверяем окружение
    print("Проверка окружения:")
    print(f"- Текущая директория: {os.getcwd()}")
    print(f"- Доступные скрипты: {len(os.listdir('/scripts/advanced_analytics'))}")
    
    # Выполняем пайплайн
    pipeline = RetailAnalyticsMaster()
    success = pipeline.execute_full_pipeline()
    
    if success:
        print("\n ПАЙПЛАЙН УСПЕШНО ВЫПОЛНЕН!")
        print("Все аналитические задания и визуализации завершены.")
    else:
        print("\n ПАЙПЛАЙН ЗАВЕРШЕН С ОШИБКАМИ")
        print("Некоторые задания могли завершиться с ошибкой. Проверьте отчет для деталей.")
    
    exit(0 if success else 1)
```

</details>

### 1.3. Копирование в кластер

```bash
# Из хоста копируем мастер-скрипт в контейнер
docker cp advanced_analytics/run_retail_pipeline.py namenode:/scripts/

# Проверяем копирование
docker-compose exec namenode ls -la /scripts/


## Часть 2: Настройка и запуск пайплайна в кластере

### 2.1. Запуск Hadoop кластера

```bash
# Запускаем Docker Compose (если еще не запущено)
cd ~/hadoop_retail_analysis
docker-compose up -d

# Проверяем статус
docker-compose ps

# Должны видеть:
# namenode    запущен
# datanode1   запущен  
# datanode2   запущен
# datanode3   запущен
```

### 2.2. Подготовка данных в HDFS

```bash
# Входим в контейнер namenode
docker-compose exec namenode bash

# Проверяем HDFS
hdfs dfsadmin -report

# Создаем базовую структуру
hdfs dfs -mkdir -p /data/retail
hdfs dfs -mkdir -p /data/retail/analytics

# Копируем данные в HDFS
hdfs dfs -put /data/input/retail_sales_dataset.csv /data/retail/

# Проверяем
hdfs dfs -ls /data/retail/
# Должен быть: retail_sales_dataset.csv
```

### 2.3. Запуск полного пайплайна

```bash
# Переходим в директорию со скриптами
cd /scripts/

# Даем права на выполнение
chmod +x run_retail_pipeline.py

# Запускаем пайплайн
python3 run_retail_pipeline.py

# ИЛИ с подробным логированием
python3 run_retail_pipeline.py 2>&1 | tee pipeline_execution.log
```

## Часть 3: Мониторинг выполнения

### 3.1. Мониторинг через Web UI

```
1. Интерфейс Hadoop NameNode: http://localhost:9870
   - Просмотр структуры HDFS
   - Мониторинг использования

2. Просмотр логов выполнения:
   docker-compose logs namenode
   docker-compose logs datanode1
```

### 3.2. Проверка выполнения в реальном времени

```bash
# В отдельном терминале мониторим HDFS
docker-compose exec namenode bash
watch -n 5 "hdfs dfs -ls -R /data/retail/analytics/"

# Или смотрим логи выполнения
tail -f /tmp/pipeline_execution.log
```

### 3.3. Промежуточные проверки

```bash
# Проверка статуса каждого модуля
# Во время выполнения можно проверять:

# 1. Проверка создания выходных директорий
hdfs dfs -ls /data/retail/analytics/

# 2. Проверка наличия результатов
hdfs dfs -ls /data/retail/analytics/sales_trends/

# 3. Просмотр первых строк результатов
hdfs dfs -cat /data/retail/analytics/sales_trends/part-00000 | head -5
```

## Часть 4: Результаты и визуализация

### 4.1. Структура результатов после выполнения

```
Структура HDFS:
/data/retail/
├── retail_sales_dataset.csv
└── analytics/
    ├── sales_trends/              # Результаты Secondary Sort
    │   ├── part-00000
    │   ├── part-00001
    │   └── _SUCCESS
    ├── customer_segments/         # Результаты Composite Keys
    │   ├── part-00000
    │   └── _SUCCESS
    ├── product_performance/       # Результаты Multiple Outputs
    ├── price_analysis/            # Результаты Price Elasticity
    ├── demographic_analysis/      # Результаты Demographic
    ├── time_patterns/             # Результаты Time Patterns
    └── revenue_dynamics/          # Результаты Revenue Dynamics

Локальные файлы (в /scripts/):
├── secondary_sort_analysis.png
├── composite_keys_analysis.png
├── multiple_outputs_analysis.png
├── price_elasticity_analysis.png
├── demographic_category_analysis.png
├── time_patterns_analysis.png
├── revenue_dynamics_analysis.png
└── pipeline_execution_report.txt
```

### 4.2. Команды для проверки результатов

```bash
# 1. Проверка всех результатов
cd /scripts
ls -la *.png
cat pipeline_execution_report.txt

# 2. Просмотр результатов из HDFS
hdfs dfs -cat /data/retail/analytics/sales_trends/part-00000 | head -10
hdfs dfs -cat /data/retail/analytics/customer_segments/part-00000 | head -10

# 3. Скачивание всех результатов локально
mkdir -p /data/output/results
hdfs dfs -get /data/retail/analytics/* /data/output/results/

# 4. Генерация сводного дашборда
python3 visualize_results.py
```

### 4.3. Автоматическая проверка целостности

```bash
# Скрипт проверки результатов
cat > /scripts/verify_pipeline.sh << 'EOF'
#!/bin/bash
echo "Проверка результатов пайплайна..."
echo "=================================="

# Проверка визуализаций
echo "1. Визуализации:"
for viz in secondary_sort composite_keys multiple_outputs price_elasticity demographic_category time_patterns revenue_dynamics; do
    if [ -f "/scripts/${viz}_analysis.png" ]; then
        echo "  ✓ ${viz}_analysis.png"
    else
        echo "  ✗ ${viz}_analysis.png - НЕ НАЙДЕН"
    fi
done

# Проверка результатов в HDFS
echo -e "\n2. Результаты в HDFS:"
for dir in sales_trends customer_segments product_performance price_analysis demographic_analysis time_patterns revenue_dynamics; do
    hdfs dfs -test -d /data/retail/analytics/${dir}
    if [ $? -eq 0 ]; then
        count=$(hdfs dfs -ls /data/retail/analytics/${dir}/part* 2>/dev/null | wc -l)
        echo "  ✓ ${dir}: ${count} файлов"
    else
        echo "  ✗ ${dir}: ДИРЕКТОРИЯ НЕ НАЙДЕНА"
    fi
done

# Проверка отчета
echo -e "\n3. Отчеты:"
if [ -f "/scripts/pipeline_execution_report.txt" ]; then
    lines=$(wc -l < /scripts/pipeline_execution_report.txt)
    echo "  ✓ pipeline_execution_report.txt (${lines} строк)"
else
    echo "  ✗ pipeline_execution_report.txt - НЕ НАЙДЕН"
fi

echo -e "\nПроверка завершена!"
EOF

chmod +x /scripts/verify_pipeline.sh
/scripts/verify_pipeline.sh
```

## Часть 5: Устранение неполадок

### 5.1. Общие проблемы и решения

```bash
# 1. Проблема: HDFS не доступен
# Решение:
docker-compose restart namenode
docker-compose restart datanode1 datanode2 datanode3
hdfs dfsadmin -safemode leave

# 2. Проблема: Не хватает памяти
# Решение: Увеличить память в docker-compose.yml
# Добавить в сервисы:
# namenode:
#   environment:
#     - HADOOP_HEAPSIZE=2048

# 3. Проблема: Скрипты не найдены
# Решение:
docker cp advanced_analytics/ namenode:/scripts/

# 4. Проблема: Ошибки при выполнении MapReduce
# Решение: Проверить логи
yarn logs -applicationId <application_id>
```

### 5.2. Логирование и отладка

```bash
# 1. Подробное логирование
python3 run_retail_pipeline.py --verbose 2>&1 | tee debug.log

# 2. Просмотр логов Hadoop
docker-compose logs namenode --tail=100

# 3. Проверка статуса YARN
yarn application -list

# 4. Просмотр логов конкретного приложения
yarn logs -applicationId application_123456789_0001
```

## Часть 6: Автоматизация и планирование

### 6.1. Скрипт автоматического развертывания

**`deploy_pipeline.sh`** (на хосте):
```bash
#!/bin/bash
echo "Развертывание пайплайна анализа ритейл-данных"
echo "============================================="

# 1. Копирование скриптов
echo "1. Копирование скриптов в кластер..."
docker cp advanced_analytics/run_retail_pipeline.py namenode:/scripts/advanced_analytics/

# 2. Настройка прав
echo "2. Настройка прав доступа..."
docker-compose exec namenode chmod +x /scripts/advanced_analytics/run_retail_pipeline.py

# 3. Подготовка HDFS
echo "3. Подготовка HDFS..."
docker-compose exec namenode hdfs dfs -mkdir -p /data/retail/analytics
docker-compose exec namenode hdfs dfs -put /data/input/retail_sales_dataset.csv /data/retail/ 2>/dev/null

# 4. Запуск пайплайна
echo "4. Запуск пайплайна..."
docker-compose exec -d namenode python3 /scripts/advanced_analytics/run_retail_pipeline.py

echo "Готово! Пайплайн запущен."
echo "Мониторинг: docker-compose logs namenode"
```

### 6.2. Планирование регулярного выполнения

```bash
# Создание cron job (на хосте)
crontab -e

# Добавить (например, каждую ночь в 2:00):
0 2 * * * cd ~/hadoop_retail_analysis && ./deploy_pipeline.sh
```

## Итоговая последовательность действий

```mermaid
graph TD
    A[Подготовка на хосте] --> B[Запуск Docker Compose]
    B --> C[Копирование скриптов в кластер]
    C --> D[Настройка HDFS]
    D --> E[Запуск мастер-пайплайна]
    E --> F[Выполнение 7 MapReduce Jobs]
    F --> G[Генерация визуализаций]
    G --> H[Создание отчета]
    H --> I[Верификация результатов]
    I --> J[Готовые бизнес-инсайты]
```

### Команды для быстрого запуска:

```bash
# Полный цикл одной командой:
cd ~/hadoop_retail_analysis
docker-compose up -d
docker cp advanced_analytics/run_retail_pipeline.py namenode:/scripts/advanced_analytics/
docker-compose exec namenode python3 /scripts/advanced_analytics/run_retail_pipeline.py
```

# Просмотр всех графиков с помощью feh

## Команды для просмотра всех графиков:

```bash
# 1. Сначала скопируем все графики на хост, если еще не сделали
mkdir -p ~/hadoop_retail_analysis/results
docker cp namenode:/scripts/combined_analysis.png ~/hadoop_retail_analysis/results/
docker cp namenode:/scripts/comprehensive_time_analysis.png ~/hadoop_retail_analysis/results/
docker cp namenode:/scripts/demographic_category_analysis.png ~/hadoop_retail_analysis/results/
docker cp namenode:/scripts/multiple_outputs_analysis.png ~/hadoop_retail_analysis/results/
docker cp namenode:/scripts/price_elasticity_analysis.png ~/hadoop_retail_analysis/results/
docker cp namenode:/scripts/revenue_dynamics_analysis.png ~/hadoop_retail_analysis/results/
docker cp namenode:/scripts/secondary_sort_analysis.png ~/hadoop_retail_analysis/results/
docker cp namenode:/scripts/time_patterns_analysis.png ~/hadoop_retail_analysis/results/

# 2. Переходим в директорию с графиками
cd ~/hadoop_retail_analysis/results

# 3. Проверяем что файлы есть
ls -la *.png

# 4. Просмотр ВСЕХ графиков одним слайд-шоу
feh -F -Z -D 5 --cycle-once *.png

# ИЛИ с автоматическим переключением каждые 3 секунды
feh -F -Z -D 3 *.png

# ИЛИ в полноэкранном режиме с возможностью переключения стрелками
feh -F -Z *.png
```




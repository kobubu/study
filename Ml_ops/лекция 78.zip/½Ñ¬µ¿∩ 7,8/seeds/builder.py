from clients.operations_client import OperationsClient, get_operations_client
from seeds.schema.plan import SeedsPlan
from seeds.schema.result import SeedsResult, SeedOperationResult


class SeedsBuilder:
    """
    Основной билдер для генерации сидинговых данных (через API-клиентов).

    Отвечает за выполнение плана сидинга — создание всех необходимых сущностей
    (на текущем этапе — только операций), с соблюдением всей бизнес-логики приложения.
    """

    def __init__(self, operations_client: OperationsClient):
        """
        Инициализация билдера с API-клиентом для операций.

        :param operations_client: Клиент, обеспечивающий вызовы к операциям.
                                  Обычно это HTTPX-клиент с базовой или нагрузочной конфигурацией.
        """
        self.operations_client = operations_client

    def build_operation_result(self) -> SeedOperationResult:
        """
        Создаёт одну операцию через API и оборачивает её результат
        в модель `SeedOperationResult`, пригодную для последующего использования в тестах.

        :return: SeedOperationResult с ID созданной операции.
        """
        operation = self.operations_client.create_operation()
        return SeedOperationResult(operation_id=operation.id)

    def build(self, plan: SeedsPlan) -> SeedsResult:
        """
        Основной метод генерации сидинговых данных согласно плану.

        Выполняет создание операций по количеству, указанному в `plan.operations.count`.

        :param plan: Объект `SeedsPlan`, описывающий, какие сущности и в каком количестве необходимо создать.
        :return: SeedsResult — итоговый набор данных, пригодный для использования в нагрузочных сценариях.
        """
        return SeedsResult(
            operations=[self.build_operation_result() for _ in range(plan.operations.count)]
        )


def get_seeds_builder() -> SeedsBuilder:
    """
    Упрощённый фабричный метод для получения готового билдера.

    Использует стандартный HTTP-клиент (не Locust) для подготовки данных.
    Этот метод можно подменить в тестах или заменить при необходимости изолированной конфигурации.
    """
    return SeedsBuilder(operations_client=get_operations_client())
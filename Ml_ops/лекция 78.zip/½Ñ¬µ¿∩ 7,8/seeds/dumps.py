import os

from seeds.schema.result import SeedsResult

def save_seeds_result(result: SeedsResult, scenario: str):
    """
    Сохраняет результат сидинга в JSON-файл в директорию ./dumps.

    :param result: Объект SeedsResult с данными о созданных сущностях.
    :param scenario: Название сценария (будет использовано в имени файла).
    """
    if not os.path.exists("dumps"):
        os.mkdir("dumps")  # создаём директорию, если её ещё нет

    seeds_file = f"./dumps/{scenario}_seeds.json"
    with open(seeds_file, 'w+', encoding="utf-8") as file:
        file.write(result.model_dump_json())  # сериализуем через Pydantic
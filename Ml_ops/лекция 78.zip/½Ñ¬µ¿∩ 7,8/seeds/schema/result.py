import random

from pydantic import BaseModel, Field


class SeedOperationResult(BaseModel):
    """
    Результат сидинга одной операции.

    Содержит идентификатор (ID), который вернулся от API после создания операции.
    Может использоваться в тестах или последующей логике — например, для получения подробностей операции.
    """
    operation_id: int  # Уникальный ID созданной операции


class SeedsResult(BaseModel):
    """
    Общий результат сидинга. Хранит созданные сущности по типам.

    Сейчас содержит только операции, но в дальнейшем может быть дополнен пользователями, счетами и т.п.
    """

    operations: list[SeedOperationResult] = Field(default_factory=list)

    def get_next_operation(self) -> SeedOperationResult:
        """
        Возвращает следующую созданную операцию (в порядке добавления).
        
        Используется для последовательных сценариев, например, когда операции используются строго одна за другой.
        """
        return self.operations.pop(0)

    def get_random_operation(self) -> SeedOperationResult:
        """
        Возвращает случайную операцию из уже созданных.

        Используется для имитации произвольного пользовательского поведения.
        """
        return random.choice(self.operations)
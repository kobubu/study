from locust import task

from schema.operations import OperationSchema
from tools.locust.task_set import BaseLocustSequentialTaskSet
from tools.locust.user import BaseLocustUser


class GetOperationSequentialTaskSet(BaseLocustSequentialTaskSet):
    # Храним объект созданной операции, чтобы использовать в следующих шагах
    operation: OperationSchema | None = None

    @task
    def create_operation(self):
        # Создаём новую операцию через API — это имитирует действие пользователя,
        # например, покупку или перевод в приложении
        self.operation = self.operations_client.create_operation()

    @task
    def get_operations(self):
        # Получаем список всех операций текущего пользователя
        self.operations_client.get_operations()

    @task
    def get_operation(self):
        # Пытаемся получить детали по конкретной операции
        # Однако операция могла не создаться — например, сервис вернул 500 или 429
        # Поэтому делаем проверку и корректно выходим
        if not self.operation:
            return

        self.operations_client.get_operation(self.operation.id)


class GetOperationUser(BaseLocustUser):
    # Указываем TaskSet, который будет выполняться этим пользователем
    tasks = [GetOperationSequentialTaskSet]
from locust import events, task
from locust.env import Environment

from seeds.builder import get_seeds_builder
from seeds.dumps import save_seeds_result
from seeds.schema.plan import SeedsPlan, SeedOperationsPlan
from seeds.schema.result import SeedOperationResult
from tools.locust.task_set import BaseLocustTaskSet
from tools.locust.user import BaseLocustUser


@events.init.add_listener
def init(environment: Environment, **kwargs):
    # Выполняем сидинг перед запуском пользователей.
    # Это важно: при старте теста система уже должна содержать готовые операции.
    builder = get_seeds_builder()

    # Формируем план сидинга: создадим 20 операций через API
    result = builder.build(plan=SeedsPlan(operations=SeedOperationsPlan(count=20)))

    # Сохраняем результат в файл — для дебага, воспроизводимости и реюза
    save_seeds_result(result=result, scenario="get_operations_with_seeds")

    # Кладём результат в environment, чтобы он был доступен всем пользователям
    environment.seeds = result


class GetOperationTaskSet(BaseLocustTaskSet):
    seed_operation: SeedOperationResult

    def on_start(self) -> None:
        super().on_start()

        # При старте каждого пользователя выбираем случайную операцию из сидинга
        self.seed_operation = self.user.environment.seeds.get_random_operation()

    @task(1)
    def get_operations(self):
        # Пользователь запрашивает список операций
        self.operations_client.get_operations()

    @task(3)
    def get_operation(self):
        # Пользователь смотрит детали по заранее подготовленной операции
        self.operations_client.get_operation(self.seed_operation.operation_id)


class GetOperationUser(BaseLocustUser):
    # Привязываем TaskSet к пользователю
    tasks = [GetOperationTaskSet]
from httpx import Response
from locust.env import Environment

from clients.base_client import BaseClient, ClientExtensions, get_http_client, get_locust_http_client
from config import settings
from schema.operations import CreateOperationSchema, OperationSchema, OperationsSchema
from tools.routes import APIRoutes


class OperationsClient(BaseClient):
    """
    API-клиент для работы с endpoint'ом /accounts (операции).

    Содержит низкоуровневые методы, возвращающие Response (get/post),
    и высокоуровневые, возвращающие десериализованные Pydantic-модели.
    """

    def get_operations_api(self) -> Response:
        """
        Отправляет GET-запрос на /accounts.
        Возвращает "сырой" httpx.Response без обработки.
        """
        return self.get(APIRoutes.OPERATIONS)

    def get_operation_api(self, operation_id: int) -> Response:
        """
        Отправляет GET-запрос на /accounts/{id}.
        Также передаёт шаблон маршрута через extensions["route"],
        чтобы в Locust метриках не было мусора по ID.
        """
        return self.get(
            f"{APIRoutes.OPERATIONS}/{operation_id}",
            extensions=ClientExtensions(route=f"{APIRoutes.OPERATIONS}/{{operation_id}}")
        )

    def create_operation_api(self, operation: CreateOperationSchema) -> Response:
        """
        Отправляет POST-запрос на /accounts с JSON-телом.
        Использует сериализацию через Pydantic с alias'ами.
        """
        return self.post(
            APIRoutes.OPERATIONS,
            json=operation.model_dump(mode='json', by_alias=True)
        )

    def get_operations(self) -> OperationsSchema:
        """
        Высокоуровневый метод: получает список операций и
        десериализует ответ в Pydantic-модель OperationsSchema.
        Используется в сценариях Locust и автотестах.
        """
        response = self.get_operations_api()
        return OperationsSchema.model_validate_json(response.text)

    def get_operation(self, operation_id: int) -> OperationSchema:
        """
        Высокоуровневый метод: получает одну операцию по ID
        и преобразует ответ в Pydantic-модель OperationSchema.
        """
        response = self.get_operation_api(operation_id)
        return OperationSchema.model_validate_json(response.text)

    def create_operation(self) -> OperationSchema:
        """
        Высокоуровневый метод: создаёт операцию со случайными данными,
        отправляет её на сервер, валидирует ответ как OperationSchema.
        Используется для сидинга и в нагрузке.
        """
        request = CreateOperationSchema()
        response = self.create_operation_api(request)
        return OperationSchema.model_validate_json(response.text)


def get_operations_client() -> OperationsClient:
    """
    Создаёт клиент операций без хуков Locust.
    Используется в сидинге или автономных автотестах.
    """
    return OperationsClient(client=get_http_client(settings.fake_bank_http_client))


def get_operations_locust_client(environment: Environment) -> OperationsClient:
    """
    Создаёт клиент операций с поддержкой event hooks Locust.
    Используется внутри нагрузочных сценариев.
    """
    return OperationsClient(
        client=get_locust_http_client(settings.fake_bank_http_client, environment)
    )
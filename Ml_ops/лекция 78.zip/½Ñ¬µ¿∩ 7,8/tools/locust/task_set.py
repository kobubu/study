from locust import TaskSet, SequentialTaskSet

from clients.operations_client import OperationsClient, get_operations_locust_client


class BaseLocustTaskSet(TaskSet):
    """
    Базовый класс для сценариев, использующих TaskSet (случайный порядок задач).

    В атрибуте `operations_client` хранится экземпляр клиента OperationsClient,
    который мы инициализируем в методе `on_start`, передавая туда окружение Locust.

    Этот клиент будет использоваться для отправки HTTP-запросов через httpx
    с поддержкой всех нужных хуков и метрик.
    """
    operations_client: OperationsClient  # Кастомный API-клиент для работы с операциями

    def on_start(self) -> None:
        """
        Метод, вызываемый перед началом выполнения задач (tasks).
        Здесь мы инициализируем клиента с привязкой к текущему окружению Locust.
        """
        self.operations_client = get_operations_locust_client(self.user.environment)


class BaseLocustSequentialTaskSet(SequentialTaskSet):
    """
    Базовый класс для сценариев, использующих строго последовательное выполнение задач.

    Отличие от BaseLocustTaskSet — только в типе сценария: здесь задачи выполняются
    по порядку, сверху вниз, как в обычной процедуре.
    """
    operations_client: OperationsClient

    def on_start(self) -> None:
        """
        Также инициализируем API-клиент до запуска основного сценария.
        """
        self.operations_client = get_operations_locust_client(self.user.environment)
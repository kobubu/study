# 1 ресурс
my_project/ 
└── main.tf



my_project/
├── k8s
└── network


my_project/
├── k8s
│   └── main.tf
└── network
    └── main.tf


my_project/
├── k8s
│   ├── cluster.tf
│   ├── main.tf
│   ├── node_group.tf
│   ├── service_account.tf
└── network
    ├── external_ip.tf
    ├── main.tf
    ├── security_group.tf
    └── vpc.tf



my_project/
└── network
    ├── main.tf
    ├── terraform.tfvars
    ├── variables.tf
    └── vpc.tf


my_project/
├── k8s
│   ├── cluster.tf         # Тут создается кластер кубера...
│   ├── key.json
│   ├── main.tf
│   ├── node_group.tf
│   ├── service_account.tf
│   ├── storage.key
│   ├── terraform.tfvars
│   └── variables.tf
└── network
    ├── external_ip.tf
    ├── key.json
    ├── locals.tf
    ├── main.tf
    ├── outputs.tf
    ├── security_group.tf
    ├── storage.key
    ├── terraform.tfvars
    ├── variables.tf
    └── vpc.tf

my_project/
└── network
    ├── external_ip.tf
    ├── key.json
    ├── locals.tf
    ├── main.tf
    ├── outputs.tf
    ├── security_group.tf
    ├── storage.key
    ├── terraform.tfvars
    ├── variables.tf
    └── vpc.tf
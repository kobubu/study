docker stop node-exporter cadvisor blackbox-exporter -t 10 2>$null
docker rm node-exporter cadvisor blackbox-exporter 2>$null

docker run -d --rm --name node-exporter -p 9100:9100 --memory=64m -v "/proc:/host/proc:ro" -v "/sys:/host/sys:ro" -v "/:/rootfs:ro" prom/node-exporter:v1.1.2
docker run -d --rm --name cadvisor -p 8080:8080 --privileged -v "/:/rootfs:ro" -v "/var/run:/var/run:ro" -v "/sys:/sys:ro" -v "/var/lib/docker/:/var/lib/docker:ro" -v "/dev/disk/:/dev/disk:ro" gcr.io/cadvisor/cadvisor:v0.44.0
docker run -d --rm --name blackbox-exporter -p 9115:9115 --memory=64m prom/blackbox-exporter:v0.22.0